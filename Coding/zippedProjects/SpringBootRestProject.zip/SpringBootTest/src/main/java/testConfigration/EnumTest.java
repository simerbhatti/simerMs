package testConfigration;


class EnumTest {

  public static void main(String[] args) {
	System.out.println("hello world");
	Color.RED.printValue(Color.RED);
}



  private enum Color{


	  RED ("laal"){
		  private int t=10;
		  private void printValue(Color c){
				  System.out.println();
			  }
	  },
	  BLUE("neela"),
	  GREEN("haraa");

	  String s=null;

	  Color(String s){
		  this.s=s;
	  }
	  private void printValue(Color c){
         if (c==Color.RED)
		  System.out.println("other than red");



	  }


  }



}

