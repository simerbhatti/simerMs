package testConfigration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class WelcomeController {

    private static final Logger logger = LoggerFactory.getLogger(WelcomeController.class);

    {

    	System.out.println("Welcome mein aaya....  ");
    }

    @Autowired
    private AppProperties app;

    @Autowired
    private GlobalProperties global;

    public AppProperties getApp() {
		return app;
	}

	public void setApp(AppProperties app) {
		this.app = app;
	}

	public GlobalProperties getGlobal() {
		return global;
	}

	public void setGlobal(GlobalProperties global) {
		this.global = global;
	}

	public static Logger getLogger() {
		return logger;
	}

	@RequestMapping("/simer")
    public String welcome(Map<String, Object> model) {
    	try{
    		System.out.println("insidddddde controller:::::>  ");
        String appProperties = app.toString();
        String globalProperties = global.toString();
        model.put("message", appProperties + globalProperties);
    	}
    	catch(Exception e){
    		return e.getMessage();
    	}
        return "welcome";
    }

}