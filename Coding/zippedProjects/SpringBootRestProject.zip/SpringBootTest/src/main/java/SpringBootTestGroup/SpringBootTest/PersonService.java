package SpringBootTestGroup.SpringBootTest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(1)
@Scope("prototype")
public class PersonService {

	{
		System.out.println(":::::PersonService::::order 2:::::");

	}
	@Autowired
	Person p;

	public void printPersonNameId(){
		p.setName("maungilaal  ");
		System.out.println("hi person::  "+p.getName());
	}

}