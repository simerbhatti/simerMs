package SpringBootTestGroup.SpringBootTest;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 *  @RestController -->meaning it’s ready for use by
 * Spring MVC to handle web requests. @RequestMapping maps / to the index()
 * method. When invoked from a browser or using curl on the command line, the
 * method returns pure text. That’s because @RestController combines @Controller
 * and @ResponseBody, two annotations that results in web requests returning
 * data rather than a view.
 */

@Controller

public class HelloController {

	@RequestMapping(value = "/index")
	@ResponseBody
	public String index() {
		 JsonObject jobj20 = (JsonObject) new JsonParser().parse("{'versionId':'976489','OfferCode':'38688561'}");

		return jobj20.getAsString();
	}

}